# EcoBytes Viva and Presentation Notes

A quick reference sheet for project defense and technical presentations.

## Project Summary
- EcoBytes is an atmospheric decision-support system forecasting air quality up to 72 hours ahead for Delhi-NCR.
- Uses Open-Meteo GFS/ECMWF weather predictions and Copernicus CAMS atmospheric chemistry guidance.
- Incorporates boundary-layer physics: vertical temperature inversion lapse rates and ventilation index scaling.
- Tracks regional stubble-burning smoke transport via NASA FIRMS VIIRS satellite thermal anomalies.
- Computes statutory Indian NAQI based on official Central Pollution Control Board (CPCB) Table 1 breakpoints.

## Validated Components
- CPCB AQI Calculations: Unit-tested against official Table 1 statutory breakpoints in tests/test_cpcb.py (dominant pollutant selection, category thresholds, sub-index formulas).
- Inversion Physics: Unit-tested in tests/test_inversion.py (lapse rate bounds, stable boundary layer scores between 0.0 and 1.0, and ventilation index scaling).
- Data Provenance Guards: Unit-tested in tests/test_ingest.py (ensures model/reanalysis data cannot masquerade as station observations, and prevents test fixtures from entering training or evaluation).
- 72-Hour Forecast Structure: Unit-tested in tests/test_forecast_engine.py (produces bounded, non-negative multi-pollutant curves across all 72 horizons).

## Non-Validated Components (Current Limitations)
- Forecast Accuracy on Ground Stations: The residual ML model has not yet been evaluated against continuous ambient monitoring station data (CAAQMS).
- Numerical Weather Prediction Baseline: A formal NWP comparison requires archived forecast runs (Open-Meteo historical forecasts) rather than reanalysis.
- Real observations are required before computing legitimate MAE/RMSE metrics.

## Answering: "Why is the ML model untrained?"
- Target formulation: The ML model is a residual bias corrector, predicting residual = observed_pm25 - cams_pm25.
- Data integrity guard: Training on CAMS reanalysis with observed = CAMS would make the target identically zero, producing a trivial model that learns nothing.
- Pre-flight requirement: Training and evaluation strictly require at least 14 days and 500 hourly records of real in-situ station data from CPCB or OpenAQ.
- Current behavior: Until real station data is ingested, the system honestly reports status NOT_TRAINED, shows a status banner on the dashboard, and relies on physics-guided CAMS forecasts.

## Technical Details
- Validation strategy: Chronological walk-forward split (70% train, 30% holdout) and Leave-One-Station-Out cross-validation (LOSO-CV) to avoid temporal and spatial leakage.
- Fallback architecture: Built-in pure-Python regressor runs if scikit-learn is not installed.
- Ingestion parser: Handles CPCB portal export formats, day-first timestamps, missing values, and NA representations.
